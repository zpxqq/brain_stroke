import torch
import numpy as np
from scipy import ndimage

from models.unet import UNet


def load_model(path):
    """Load trained 2D U-Net weights on CPU."""
    model = UNet()
    state = torch.load(path, map_location="cpu")
    if isinstance(state, dict) and "state_dict" in state:
        state = state["state_dict"]
    model.load_state_dict(state)
    model.eval()
    return model


def predict(model, image):
    """Run inference on a 3-channel image array [C,H,W]."""
    image = torch.as_tensor(image, dtype=torch.float32).unsqueeze(0)

    with torch.no_grad():
        logits = model(image)
        confidence = torch.sigmoid(logits).squeeze().cpu().numpy()

    mask = confidence > 0.5
    return mask, confidence


def count_lesions(mask, min_size=1, connectivity=2):
    """Count connected lesion components and return labels and pixel sizes.

    Parameters
    ----------
    mask : array-like
        Binary 2D lesion mask.
    min_size : int
        Ignore components smaller than this number of pixels.
    connectivity : int
        1 = 4-neighbourhood, 2 = 8-neighbourhood for a 2D mask.

    Returns
    -------
    count : int
        Number of retained lesion components.
    labels : ndarray
        Relabelled component map, starting at 1.
    sizes : list[int]
        Pixel area of each retained component.
    """
    binary = np.asarray(mask, dtype=bool)
    if binary.ndim != 2:
        raise ValueError(f"count_lesions expects a 2D mask, got shape {binary.shape}")

    connectivity = 1 if connectivity <= 1 else 2
    structure = ndimage.generate_binary_structure(2, connectivity)
    raw_labels, num = ndimage.label(binary, structure=structure)

    if num == 0:
        return 0, np.zeros_like(raw_labels, dtype=np.int32), []

    component_sizes = np.bincount(raw_labels.ravel())
    keep = component_sizes >= max(1, int(min_size))
    keep[0] = False

    labels = np.zeros_like(raw_labels, dtype=np.int32)
    sizes = []
    new_id = 0

    for old_id in range(1, num + 1):
        if keep[old_id]:
            new_id += 1
            labels[raw_labels == old_id] = new_id
            sizes.append(int(component_sizes[old_id]))

    return new_id, labels, sizes
