# МРТешечка — Streamlit Cloud

## Entry point
Use `streamlit_app.py` as the Main file.

## Dependencies
`requirements.txt` contains the dependencies required by the Streamlit interface.

## Model weights
The repository currently does not contain trained U-Net weights (`.pth`, `.pt`, `.ckpt`).
Therefore the app works in demo mode until a trained checkpoint is provided.

To use a real model, upload the checkpoint to the repository (or another supported storage) and enter its relative path in the sidebar, for example:

`weights/best_unet.pth`

## Supported uploads
- PNG
- JPG/JPEG
- NIfTI `.nii`
- NIfTI `.nii.gz`

For NIfTI, the current interface displays the central slice of the selected volume.

## Streamlit Cloud
Main file: `streamlit_app.py`
